Python3 Package Fundamentals.
ProjectPython 101 - How to Create a Python Package.
This is a simple way to start developing own pacakages for Python3.
Getting started
Dependencies 
Installing
Executing the program
Help
Authors
Version History

License
Acknowledgmentd


